# The-EvenOdd
A PyThon Program To Predict A Number's Nature Whether Even Or Odd.  [% function]
A Program Coded By Ayush Jha!
HAPPY CODING!!!!!!!!!
