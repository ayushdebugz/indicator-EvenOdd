
"""
Created on Fri Oct 12 20:34:41 2018

@author: Ayush_XI-A;
"""
#Spyder Program "Even" Or "Odd"
#Even Odd Program using Modulus Operator  
a=int(input("Please Enter A Number : "));  
if(a%2==0):   #  ' % 'meaning remainder 
    print("An Even Number!")  
else:  
    print("An Odd Number!")



